document.getElementById("btn").onclick = function () {
  // 点按钮后弹出一个文字，你可以尝试改变文字内容
  alert("你好啊，欢迎来到我的个人页面");
}